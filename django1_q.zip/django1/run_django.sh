#!/bin/sh

# 設定 Python 腳本的路徑（如果不在系統 PATH 中）
PYTHON_EXECUTABLE="/home/briante/demo/my_env/bin/python"

# 切換到你的 Django 專案的目錄
cd /home/briante/demo/django1

# 啟動 Django 開發伺服器（後台運行）
$PYTHON_EXECUTABLE manage.py runserver &

# 啟動 Django-Q 排程伺服器（後台運行）
$PYTHON_EXECUTABLE manage.py qcluster &

# 按Ctrl+C或SIGTERM优雅关闭
# Django接口将变为不可用