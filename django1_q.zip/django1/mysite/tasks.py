# mysite/tasks.py

from celery import shared_task
from datetime import datetime

@shared_task
def my_celery_task():
    #檢查django_app是否啟用
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"Celery task executed at {current_time}")
